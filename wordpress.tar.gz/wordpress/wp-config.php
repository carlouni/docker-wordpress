<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wp' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'securepass' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'SS]LU7s>H]f}K.(_/2:>XQ(9E`9MD<E2HBQ>SI]w;XdrEV*>KXk!xnpt*xT<0W:r' );
define( 'SECURE_AUTH_KEY',  'BE5zQ*Dlw`* kLDgO4=2}!k?9n=0A]2vTCQT?7*16CRrlqzcgO,5Xc|SCbLk}h[ ' );
define( 'LOGGED_IN_KEY',    '%%<e_=5Mz&y-xP9UxRdx@I>n1i;Cf: .wt|=Z(x3>D)h:W04N(*8y?U4l`F=:|VA' );
define( 'NONCE_KEY',        'S>jpZDc@U#9]p)SRqdi]pml.hY& ? YwY X{MjMmILOq3F]In5+`axV2{EI%n7[(' );
define( 'AUTH_SALT',        '+P]4:pa2O&my*QQ uxl69PMVA_(J*| UJpqnWp1mz5C!OomGb&WC^?x@^ k7Y+|J' );
define( 'SECURE_AUTH_SALT', 'f 9FfHIZ&@,5qaCl;hHrOj+r}U^EkzyVuxvc}1#+yd-tbtjLu|0DOT~!?[?quaH2' );
define( 'LOGGED_IN_SALT',   'm18TW+cPfQ:*.8#>{7w;!WeM_v`B@Q%e%b f<n~963DSXB[y.@my?#YEBdUK&E&t' );
define( 'NONCE_SALT',       'yj&{L68D_Bs:,hDK>z[r(g;&368 J64PX%?j0zs1]DoC5$s9bqvnst2IfoN>Dz.q' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
